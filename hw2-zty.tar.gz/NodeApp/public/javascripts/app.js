var app = angular.module('angularjsNodejsTutorial', []);
//angular.module('app', ['ngRoute']);

app.controller('loginController', function($scope, $http) {
  $scope.verifyLogin = function() {
    // To check in the console if the variables are correctly storing the input:
    // console.log($scope.username, $scope.password);

    $http({
      url: '/login',
      method: "POST",
      data: {
        'username': $scope.username,
        'password': $scope.password
      }
    }).then(
    res => {
      window.location.href = "http://localhost:8081/dashboard"
    },err => {
      console.log("Add Row ERROR: ", err);
    });

  };
});


app.controller('dashboardUserController', function($scope, $http) {
  $http({
    url: '/usernames',
    method: 'GET'
  }).then(
  res => {
    console.log("Username", res.data);
    $scope.usernames=res.data;
  },err => {
    console.log("Find Username ERROR: ", err);
  });

});


app.controller('dashboardMovieController', function($scope, $http) {
  $http({
    url: '/genres',
    method: 'GET'
  }).then(
  res => {
    console.log("Genres", res.data);
    $scope.genres=res.data;
  },err => {
    console.log("Find Genres ERROR: ", err);
  });
  
  $scope.generatetop10 = function(genre) {
    $http({
    url: '/genres/'+genre,
    method: 'GET'
  }).then(
res => {
console.log("Genre", res.data);
    $scope.slgenre=res.data;
  },err => {
    console.log("Find Genre ERROR: ", err);
  });
  }
  
});

app.controller('rcmdMovieController', function($scope, $http) {
  $scope.getfavoritemovies = function(){
    console.log($scope.movieid1,$scope.movieid2,$scope.movieid3)
    $http({
      url: '/rcmdmovies',
      method: "POST",
      data: {
        'movieid1': $scope.movieid1,
        'movieid2': $scope.movieid2,
        'movieid3': $scope.movieid3
      }      
	})
	.then(function(response){
	  if(response){
	    $scope.genre=angular.fromJson(response.data)[0].genre;
//         console.log($scope.genre)
  	    return $scope.genre
	  }//if(response){}    
	})
	.then(function(maxgenre) {
// 	  console.log(maxgenre)
	  $http({
  		url: '/genres/'+maxgenre,
    	method: 'GET'
  	  })
  	  .then(function(response){
	  if(response){
// 	  	console.log(response.data)
	    $scope.slgenre=response.data;
	  }//if(response){}    
	  })
	  .catch(err => {
      console.log("Find rcmdMovie ERROR: ", err);
	  });//catch
	})
	.catch(err => {
      console.log("Find MaxGenre ERROR: ", err);
	});
  
  }//functoin(){
});

app.controller('bestofMovieController', function($scope, $http) {
  $http({
    url: '/decades',
    method: 'GET'
  }).then(
  res => {
    console.log("Decades", res.data);
    $scope.decades=res.data;
  },err => {
    console.log("Find Decades ERROR: ", err);
  });
  
  $scope.gettop = function(){
    console.log($scope.sldecade)
    $http({
    url: '/topmovie',
    method: 'POST',
    data: {
    'sldecade':$scope.sldecade
    }//不知道刚刚这个花括号出了什么问题
    })
    .then(
    res => {
    console.log("Decades", res.data);
    $scope.topmovies=res.data;
    },err => {
    console.log("Find Decades ERROR: ", err);
    });
  
  };//$scope.gettop = function(){
  
  

})


app.controller('posterController', function($scope, $http, $sce, $window) {
//   $http({
//     url: '/movieid',
//     method: 'GET'
//   })
// 	.then(
//     res => {
//     console.log("Decades", res.data);
//     $scope.mvids=res.data;
//     },err => {
//     console.log("Find Decades ERROR: ", err);
//     });
// 	
//   $http({
//   		url: '/'+mvid,
//     	method: 'GET'
//   	    })
 

$http({
    url: '/movieid',
    method: 'GET'
  })
  .then(function(response){
	  if(response){
	    $scope.mvids=response.data;
//         console.log($scope.mvids)
  	    return $scope.mvids
	  }//if(response){}    
	})
  .then(function(mvids) {
	  var i;
	  $scope.rst=[]
	  //var $scope.rst={};
	  for (i = 0; i < mvids.length; i++) { 
  		console.log(mvids[i].imdb_id)
  		var mvid=mvids[i].imdb_id
  		//$scope.src = $sce.trustAsResourceUrl('http://www.omdbapi.com/?apikey=e59d84dc&i='+mvid);
	    $http({
  		url: '/'+mvid,
    	method: 'GET'
  	    })
  	    .then(function(response){
	    if(response){
	  	  //console.log(response.data)
	  	  
	  	  $scope.rst.push(angular.fromJson(response.data));
	      //console.log($scope.rst)
	    }//if(response){}    
	    })
	    .catch(err => {
        console.log("Find OMDB ERROR: ", err);
	    })
	  }//for()
	  //console.log($scope.rst.key+"aaaa")
	  console.log($scope.rst)

  })//then(function(mvids) {
  .catch(err => {
    console.log("Find MVIDs ERROR: ", err);
  });
  
  $scope.webpage=function(website){
    console.log(website)
    if(website!="N/A"){
      $window.open(website);
    }
    
  }
  
  
  
  
//   $scope.generatetop10 = function(genre) {
//     $http({
//     url: '/genres/'+genre,
//     method: 'GET'
//   }).then(
// res => {
// console.log("Genre", res.data);
//     $scope.slgenre=res.data;
//   },err => {
//     console.log("Find Genre ERROR: ", err);
//   });
//   }

});

// Template for adding a controller
/*
app.controller('dummyController', function($scope, $http) {
  // normal variables
  var dummyVar1 = 'abc';

  // Angular scope variables
  $scope.dummyVar2 = 'abc';

  // Angular function
  $scope.dummyFunction = function() {

  };
});
*/
